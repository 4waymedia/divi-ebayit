import EbayProjector from './EbayProjector/EbayProjector';

export default [EbayProjector];
